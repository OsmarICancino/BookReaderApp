<?php
require 'DatabaseConnection.php';

class Libro
{
    // Nombre de la tabla asociada a esta clase
    const TABLE_NAME = "libro";

    function __construct()
    {
    }

    /**
     * Obtiene todas las sucursales de la base de datos
     * @return array|bool Arreglo con todos las sucursales o false en caso de error
     */
    public static function getAll()
    {
        $consulta = "select * from libro;";
        try {
            // Preparar sentencia
            $comando = DatabaseConnection::getInstance()->getDb()->prepare($consulta);
            // Ejecutar sentencia preparada
            $comando->execute();

            return $comando->fetchAll(PDO::FETCH_ASSOC);

        } catch (PDOException $e) {
            return false;
        }
    }

  
}

?>
